package errorMsg;

public class ArrayTypeError extends CompError
{
    public ArrayTypeError()
    {
        super("Array type expected");
    }
}


