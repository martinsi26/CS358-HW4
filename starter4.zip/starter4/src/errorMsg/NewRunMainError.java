package errorMsg;

public class NewRunMainError extends CompError
{
    public NewRunMainError()
    {
        super("Cannot create object of type 'RunMain'");
    }
}

