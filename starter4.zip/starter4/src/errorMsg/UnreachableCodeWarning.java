package errorMsg;

public class UnreachableCodeWarning extends CompWarning
{
    public UnreachableCodeWarning()
    {
        super("Unreachable code");
    }
}
